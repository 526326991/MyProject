# 下班代码
**纯粹用于娱乐**

注意：
需要本地配置Java环境变量

## v1.0 
1. 支持修改下班时间（在info.properties）
2. 时间类型采用LocalDateTime


**关于作者**

![double_cheng](https://s2.ax1x.com/2019/12/26/lAvaWV.jpg "double_cheng")

* double_cheng@qq.com 
* https://github.com/526326991

